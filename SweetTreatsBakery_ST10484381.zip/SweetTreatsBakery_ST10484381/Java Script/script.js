/*
  script.js
  Enhancements for SweetTreatsBakery student project:
  - Render products
  - Add-to-cart with localStorage persistence
  - Form validation (enquiry + contact) with AJAX/mailto fallback
  - UI widgets: accordion, tabs, modal, lightbox gallery
  - Dynamic content loader and search/filter helper
  - Map init hook (Leaflet/Mapbox fallback)

  Usage: include this file at the end of your HTML body. Ensure markup uses
  IDs/classes referenced below (examples included in comments).
*/

/*
  script.js  — Enhanced implementation for student submission
  Features:
  - Product rendering + cart with quantity controls and localStorage
  - Cart modal rendering and checkout helper
  - Advanced form validation (email, phone, date, length) + AJAX fallback
  - UI components: accordion, tabs, modal with transitions
  - Lightbox gallery with keyboard support
  - Search / sort with debounce
  - Map init hook (Leaflet/Mapbox fallback)
  - SEO helpers (setTitle, setMetaDescription) and sitemap export helper
  - Changelog helper to assemble editable change notes for lecturer

  Place this script at the end of the HTML body. Ensure HTML contains
  elements with IDs/classes referenced in the comments below.
*/

(function () {
  const STORAGE_KEY = 'sweetTreatsCart_v2';

  /* ---------------------- Configuration ----------------------------- */
  const config = {
    currency: 'R',
    productsSelector: '#products',
    cartCountSelector: '#cart-count',
    cartSubtotalSelector: '#cart-subtotal',
    cartModalSelector: '#cart-modal'
  };

  /* ---------------------- Sample product data ----------------------- */
  const products = [
    { id: 'p1', title: 'Vanilla Cupcake', price: 22.5, img: 'images/cupcake-vanilla.jpg', tags: ['cupcake'] },
    { id: 'p2', title: 'Chocolate Cake Slice', price: 45.0, img: 'images/cake-choc.jpg', tags: ['cake'] },
    { id: 'p3', title: 'Blueberry Muffin', price: 18.0, img: 'images/muffin-blueberry.jpg', tags: ['muffin'] },
    { id: 'p4', title: 'Lemon Tart', price: 30.0, img: 'images/tart-lemon.jpg', tags: ['tart'] }
  ];

  /* ---------------------- Utilities -------------------------------- */
  function q(sel, root = document) { return root.querySelector(sel); }
  function qa(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }
  function formatPrice(n) { return `${config.currency}${Number(n).toFixed(2)}`; }
  function debounce(fn, wait = 250) { let t; return (...a) => { clearTimeout(t); t = setTimeout(()=>fn.apply(this,a), wait); }; }

  /* ---------------------- Cart with UI rendering -------------------- */
  const Cart = {
    items: {},
    load() {
      try { this.items = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch(e){ this.items = {}; }
      this.updateUI();
    },
    save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(this.items)); },
    add(id, qty = 1) { this.items[id] = (this.items[id] || 0) + qty; this.save(); this.updateUI(); },
    set(id, qty) { if (qty <= 0) delete this.items[id]; else this.items[id] = qty; this.save(); this.updateUI(); },
    remove(id) { delete this.items[id]; this.save(); this.updateUI(); },
    clear() { this.items = {}; this.save(); this.updateUI(); },
    count() { return Object.values(this.items).reduce((a,b)=>a+b,0); },
    subtotal() { return Object.entries(this.items).reduce((sum,[id,qty])=>{ const p=products.find(x=>x.id===id); return sum + (p? p.price*qty:0); },0); },
    updateUI() {
      const countEl = q(config.cartCountSelector); if (countEl) countEl.textContent = this.count();
      const subtotalEl = q(config.cartSubtotalSelector); if (subtotalEl) subtotalEl.textContent = formatPrice(this.subtotal());
      this.renderCartModal();
    },
    renderCartModal() {
      const modal = q(config.cartModalSelector); if (!modal) return;
      const body = q('.cart-body', modal); if (!body) return;
      body.innerHTML = '';
        const entries = Object.entries(this.items);
        if (entries.length === 0) { body.innerHTML = '<p>Your cart is empty.</p>'; const subtotalElEmpty = q('.cart-footer .subtotal', modal); if (subtotalElEmpty) subtotalElEmpty.textContent = formatPrice(0); return; }
      entries.forEach(([id, qty]) => {
        const p = products.find(x => x.id === id);
        const row = document.createElement('div'); row.className = 'cart-row';
        row.innerHTML = `<div class="cart-item">
          <img src="${p.img}" alt="${p.title}"/>
          <div class="cart-meta"><strong>${p.title}</strong><div class="price">${formatPrice(p.price)}</div></div>
          <div class="qty"> <button class="qty-decr" data-id="${id}">-</button> <span class="qty-val">${qty}</span> <button class="qty-incr" data-id="${id}">+</button></div>
          <button class="cart-remove" data-id="${id}">Remove</button>
        </div>`;
        body.appendChild(row);
      });
      const subtotalEl = q('.cart-footer .subtotal', modal); if (subtotalEl) subtotalEl.textContent = formatPrice(this.subtotal());
    }
  };

  /* ---------------------- Product rendering + search/sort ---------- */
  function renderProducts(containerSelector = config.productsSelector, list = products) {
    const container = q(containerSelector); if (!container) return;
    container.innerHTML = '';
    list.forEach(p => {
      const el = document.createElement('article'); el.className = 'product-card';
      el.innerHTML = `<img src="${p.img}" alt="${p.title}" loading="lazy"/>
        <h3>${p.title}</h3>
        <p class="price">${formatPrice(p.price)}</p>
        <div class="actions"><button class="add-to-cart" data-id="${p.id}">Add</button> <button class="view" data-modal-open="#product-${p.id}">View</button></div>`;
      container.appendChild(el);
      // optional product modal templates (create only once)
      if (!document.getElementById(`product-${p.id}`)) {
        const modalTpl = document.createElement('div'); modalTpl.id = `product-${p.id}`; modalTpl.className = 'modal product-modal';
        modalTpl.innerHTML = `<div class="modal-inner"><button class="modal-close" data-modal-close>×</button><img src="${p.img}" alt="${p.title}"/><h2>${p.title}</h2><p>${formatPrice(p.price)}</p><p>Delicious and fresh.</p></div>`;
        document.body.appendChild(modalTpl);
      }
    });
  }

  function initSearchAndSort() {
    const input = q('#search'); const sort = q('#sort');
    if (input) input.addEventListener('input', debounce(()=>{
      const qv = input.value.trim().toLowerCase();
      const filtered = products.filter(p => (p.title + ' ' + (p.tags||[]).join(' ')).toLowerCase().includes(qv));
      renderProducts(config.productsSelector, filtered);
    }, 200));
    if (sort) sort.addEventListener('change', ()=>{
      const val = sort.value; const copy = [...products];
      if (val === 'price-asc') copy.sort((a,b)=>a.price-b.price);
      if (val === 'price-desc') copy.sort((a,b)=>b.price-a.price);
      renderProducts(config.productsSelector, copy);
    });
  }

  /* ---------------------- Lightbox gallery --------------------------- */
  function initLightbox(selector = '.gallery img') {
    document.addEventListener('click', e => {
      const img = e.target.closest(selector);
      if (!img) return;
      openLightbox(img.src, img.alt);
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });
  }
  let lbOverlay = null;
  function openLightbox(src, alt) {
    closeLightbox();
    lbOverlay = document.createElement('div'); lbOverlay.className = 'lightbox-overlay';
    lbOverlay.innerHTML = `<div class="lightbox-content"><img src="${src}" alt="${alt||''}"/><button class="lightbox-close">×</button></div>`;
    document.body.appendChild(lbOverlay);
    lbOverlay.addEventListener('click', (ev)=>{ if (ev.target === lbOverlay || ev.target.classList.contains('lightbox-close')) closeLightbox(); });
  }
  function closeLightbox() { if (lbOverlay) { lbOverlay.remove(); lbOverlay = null; } }

  /* ---------------------- UI widgets: accordion/tabs/modal --------- */
  function initUI() {
    document.addEventListener('click', e => {
      const acc = e.target.closest('[data-accordion-toggle]'); if (acc) { const panel = q(acc.dataset.accordionToggle); if (panel) panel.classList.toggle('open'); }
      const tab = e.target.closest('[data-tab-target]'); if (tab) { const g = tab.dataset.tabGroup || 'default'; qa(`[data-tab-group="${g}"]`).forEach(t=>t.classList.remove('active')); qa(`[data-tab-content="${g}"]`).forEach(c=>c.classList.remove('active')); tab.classList.add('active'); const target = q(tab.dataset.tabTarget); if (target) target.classList.add('active'); }
      const modalOpen = e.target.closest('[data-modal-open]'); if (modalOpen) openModal(modalOpen.dataset.modalOpen.replace(/#/,''));
      const modalClose = e.target.closest('[data-modal-close]'); if (modalClose) closeModal(modalClose.closest('.modal')?.id);
      const qtyIncr = e.target.closest('.qty-incr'); if (qtyIncr) { Cart.add(qtyIncr.dataset.id, 1); }
      const qtyDecr = e.target.closest('.qty-decr'); if (qtyDecr) { const id = qtyDecr.dataset.id; Cart.set(id, (Cart.items[id]||0)-1); }
      const remove = e.target.closest('.cart-remove'); if (remove) Cart.remove(remove.dataset.id);
      const addBtn = e.target.closest('.add-to-cart'); if (addBtn) { Cart.add(addBtn.dataset.id, 1); showToast('Added'); }
    });
  }

  function openModal(id) { const m = document.getElementById(id); if (m) { m.classList.add('open'); document.body.classList.add('no-scroll'); } }
  function closeModal(id) { const m = document.getElementById(id); if (m) { m.classList.remove('open'); document.body.classList.remove('no-scroll'); } }

  /* ---------------------- Form validation & submission ------------- */
  function initForms() {
    qa('form').forEach(form => {
      form.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        clearFormMessages(form);
        const ok = validateForm(form);
        if (!ok) return;
        // AJAX endpoint if provided
        const endpoint = form.dataset.endpoint;
        const data = new FormData(form);
        if (endpoint) {
          try {
            const res = await fetch(endpoint, { method: 'POST', body: data });
            if (!res.ok) throw new Error('submit failed');
            showFormResult(form, 'success', 'Submitted successfully');
            form.reset();
          } catch (e) { showFormResult(form, 'error', 'Submission failed — try mailto'); }
        } else {
          // fallback: build mailto
          const to = form.dataset.recipient || 'info@example.com';
          const subj = encodeURIComponent(form.dataset.subject || 'Website contact');
          const body = encodeURIComponent(Array.from(data.entries()).map(([k,v])=>`${k}: ${v}`).join('\n'));
          window.location.href = `mailto:${to}?subject=${subj}&body=${body}`;
          showFormResult(form, 'success', 'Opened email client');
        }
      });
    });
  }

  function validateForm(form) {
    let ok = true;
    qa('.field-error', form).forEach(e=>e.remove());
    qa('[required]', form).forEach(el=>{ if (!el.value.trim()) { showFieldError(el, 'This field is required'); ok = false; } });
    const email = q('[type="email"]', form); if (email && email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) { showFieldError(email,'Enter a valid email'); ok = false; }
    const phone = q('[type="tel"]', form); if (phone && phone.value && !/^\+?[0-9\s\-]{7,15}$/.test(phone.value)) { showFieldError(phone,'Enter a valid phone'); ok = false; }
    const minlen = qa('[data-minlength]', form); minlen.forEach(el=>{ const n = Number(el.dataset.minlength||0); if (el.value.trim().length < n) { showFieldError(el, `At least ${n} characters`); ok=false; } });
    return ok;
  }
  function showFieldError(el, msg) { let e = el.parentElement.querySelector('.field-error'); if (!e) { e = document.createElement('div'); e.className='field-error'; el.parentElement.appendChild(e); } e.textContent = msg; el.classList.add('invalid'); }
  function clearFormMessages(form) { qa('.field-error', form).forEach(e=>e.remove()); qa('.form-result', form).forEach(e=>e.remove()); }
  function showFormResult(form, kind, msg) { const p = document.createElement('div'); p.className = 'form-result ' + kind; p.textContent = msg; form.appendChild(p); }

  /* ---------------------- Toast ------------------------------------- */
  let toastTimer = 0; function showToast(text, ms=1600) { let t = q('#global-toast'); if (!t) { t = document.createElement('div'); t.id='global-toast'; t.className='toast'; document.body.appendChild(t); } t.textContent=text; t.classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(()=>t.classList.remove('visible'), ms); }

  /* ---------------------- Map init hook ----------------------------- */
  function initMap(containerId, lat=-26.2041, lng=28.0473, zoom=13) {
    const el = document.getElementById(containerId); if (!el) return;
    if (window.L) {
      const map = L.map(containerId).setView([lat,lng], zoom);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
      L.marker([lat,lng]).addTo(map);
    } else if (window.mapboxgl) {
      try { mapboxgl.accessToken = window.MAPBOX_TOKEN || ''; const map = new mapboxgl.Map({ container: containerId, style: 'mapbox://styles/mapbox/streets-v11', center: [lng,lat], zoom }); new mapboxgl.Marker().setLngLat([lng,lat]).addTo(map); } catch(e){ console.warn('Mapbox init failed',e); }
    } else console.warn('No map library found. Include Leaflet or Mapbox to enable maps.');
  }

  /* ---------------------- SEO helpers ------------------------------- */
  function setTitle(title) { if (title) document.title = title; }
  function setMetaDescription(text) { let m = q('meta[name="description"]'); if (!m) { m = document.createElement('meta'); m.name = 'description'; document.head.appendChild(m); } m.content = text; }
  function exportSitemap(pages = [{loc:location.origin+'/' , lastmod: new Date().toISOString().split('T')[0]}]){
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${pages.map(p=>`  <url><loc>${p.loc}</loc><lastmod>${p.lastmod}</lastmod></url>`).join('\n')}\n</urlset>`;
    const blob = new Blob([xml], {type:'application/xml'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sitemap.xml'; document.body.appendChild(a); a.click(); a.remove();
  }

  /* ---------------------- Changelog helper -------------------------- */
  function appendChangelog(entry) {
    const key = 'projectChangelog'; const cur = JSON.parse(localStorage.getItem(key) || '[]'); cur.push({ts:new Date().toISOString(), entry}); localStorage.setItem(key, JSON.stringify(cur));
  }
  function exportChangelog() { const cur = JSON.parse(localStorage.getItem('projectChangelog') || '[]'); const text = cur.map(c=>`- ${c.ts}: ${c.entry}`).join('\n'); const blob = new Blob([text], {type:'text/plain'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'changelog.txt'; document.body.appendChild(a); a.click(); a.remove(); }

  /* ---------------------- Init -------------------------------------- */
  function init() {
    renderProducts();
    Cart.load();
    initUI();
    initForms();
    initLightbox();
    initSearchAndSort();
    // Expose utilities for instructor testing
    window.App = Object.assign(window.App || {}, { Cart, renderProducts, initMap, setTitle, setMetaDescription, exportSitemap, appendChangelog, exportChangelog });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  })();